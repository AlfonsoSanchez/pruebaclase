Game hello world

instruction:
press  return to exit.
